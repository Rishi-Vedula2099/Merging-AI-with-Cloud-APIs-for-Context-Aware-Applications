.. _frozen_examples:

Frozen Estimators
-----------------

Examples concerning the :mod:`sklearn.frozen` module.

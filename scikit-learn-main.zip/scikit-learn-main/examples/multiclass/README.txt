.. _multiclass_examples:

Multiclass methods
------------------

Examples concerning the :mod:`sklearn.multiclass` module.
